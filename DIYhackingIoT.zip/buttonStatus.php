<?php
$status = file_get_contents("buttonStatus.txt");
echo $status;
?>